import json
import random
def random_drink():
    
    drinks = ['beer','wine','whiskey','rum','vodka']
    return random.choice(drinks)

def lambda_handler(event, context):
    drinks=random_drink()
    message = f"You should drink some {drinks}"
    
    return {
        'statusCode': 200,
        'body': json.dumps({"message":message,"drinks":drinks})
    }
